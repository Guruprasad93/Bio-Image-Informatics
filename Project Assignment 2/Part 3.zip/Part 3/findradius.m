%Find radius of all airy disks
function [radius] = findradius(Intensity, y)

I = Intensity;

for i = 1:size(I,1)
    DataInv = 1.01*max(I(i,:)) - I(i,:);
    [Minima,MinIdx] = findpeaks(DataInv);
    maxIdx = find(I(i,:) == max(I(i,:)));
    MinIdxchanged = abs(MinIdx - maxIdx(1));
    radius(i) = y(maxIdx(1)) - y(MinIdx(find(MinIdxchanged == min(MinIdxchanged))));
end
    
    