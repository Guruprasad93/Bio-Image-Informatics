%% Question 3 - Part 2

%Set of Inputs
lambda = [480*1e-9, 520*1e-9, 680*1e-9, 520*1e-9, 520*1e-9, 680*1e-9]; 
NA = [0.5, 0.5, 0.5, 1.0, 1.4, 1.5];

y = [-50*1e-7:0.1*1e-7:50*1e-7]; %Distance along the screen
for i = 1:6
    I(i,:) = PlotAiryDisk(lambda(i),NA(i));
end

radius = findradius(I, y); %Determining Radii of the Airy disks.

BestFittedSigma = gaussianFit(I); %Determining sigma for best fitted gaussian kernel

